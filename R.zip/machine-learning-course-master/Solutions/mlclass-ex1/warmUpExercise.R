warmUpExercise  <- function() {
  #WARMUPEXERCISE Example function in R
  #   A <- WARMUPEXERCISE() is an example function that returns the 5x5 identity matrix
  

  # ------------- YOUR CODE HERE --------------
  # Instructions: Return the 5x5 identity matrix
  #               In R, the final computed variable 
  #               will be returned as output.
  
  A <- diag(5) 
  A
  
  # -------------------------------------------
  
  
}
